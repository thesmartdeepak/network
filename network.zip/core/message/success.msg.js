const msg={};

/**
 * Region related msg
 */ 
msg.allRegion="Found successfully!!!!"
msg.getOneRegion="Found one Region successfully!!!!"
msg.addRegion="Region added successfully!!!!"
msg.deleteRegion="Region deleted successfully!!!"
msg.editRegion="Region updated successfully!!!"

/**
 * User related msg
 */ 
msg.allUser="Found successfully!!!!"
msg.getOneUser="Found one User successfully!!!!"
msg.addUser="User added successfully!!!!"
msg.deleteUser="User deleted successfully!!!"
msg.editUser="User updated successfully!!!"
msg.loginUser="Login successfully!!!!"

/**
 * UserType related msg
 */ 
msg.allUserType="Found successfully!!!!"
msg.addUserType="UserType added successfully!!!!"
msg.deleteUserType="UserType deleted successfully!!!"
msg.editUserType="UserType updated successfully!!!"

/**
 * Circle related msg
 */ 
msg.allCircle="Found successfully!!!!"
msg.getOneCircle="Found one Circle successfully!!!!"
msg.addCircle="Circle added successfully!!!!"
msg.deleteCircle="Circle deleted successfully!!!"
msg.editCircle="Circle updated successfully!!!"

/**
 * Activity related msg
 */ 
msg.allActivity="Found successfully!!!!"
msg.getOneActivity="Found one Activity successfully!!!!"
msg.addActivity="Activity added successfully!!!!"
msg.deleteActivity="Activity deleted successfully!!!"
msg.editActivity="Activity updated successfully!!!"

/**
 * client related msg
 */ 
msg.allClient="Found successfully!!!!"
msg.getOneClient="Found one client successfully!!!!"
msg.addClient="Client added successfully!!!!"
msg.deleteClient="Client deleted successfully!!!"
msg.editClient="Client updated successfully!!!"

/**
 * project related msg
 */ 
msg.allProject="Found successfully!!!!"
msg.getOneProject="Found one project successfully!!!!"
msg.addProject="Projects added successfully!!!!"
msg.deleteProject="Project deleted successfully!!!"
msg.editProject="Project updated successfully!!!"

/**
 * ProjectType related msg
 */ 
msg.allProjectType="Found successfully!!!!"
msg.getOneProjectType="Found one Project type successfully!!!!"
msg.addProjectType="Project types added successfully!!!!"
msg.deleteProjectType="Project type deleted successfully!!!"
msg.editProjectType="Project type updated successfully!!!"

/**
 * department related msg
 */ 
msg.alldepartment="Found successfully!!!!"
msg.getOnedepartment="Found one department successfully!!!!"
msg.adddepartment="Departments added successfully!!!!"
msg.deletedepartment="Department deleted successfully!!!"
msg.editdepartment="Department updated successfully!!!"
/*
 * status/remark related msg
 */ 
msg.allStatusRemark="Found successfully!!!!"
msg.getOneStatusRemark="Found one status/remark successfully!!!!"
msg.addStatusRemark="Status/Remarks added successfully!!!!"
msg.deleteStatusRemark="Status/Remark deleted successfully!!!"
msg.editStatusRemark="Status/Remark updated successfully!!!"

export default msg; 